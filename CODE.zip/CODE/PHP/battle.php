<?php
// ====================================
// SETUP AND DEPENDENCIES
// ====================================

// Start output buffering to prevent header errors and ensure clean JSON output.
ob_start();
session_start();

// Include all necessary character classes
require_once __DIR__ . "/Character.php";
require_once __DIR__ . "/Doctor.php";
require_once __DIR__ . "/Thug.php";
require_once __DIR__ . "/Occultist.php";

// Configure error reporting: log errors but do not display (prevents corrupting JSON)
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

// Set the response type to JSON
header('Content-Type: application/json');

// ====================================
// CHARACTER CLASS AND STAT MAPPING
// ====================================

// Maps frontend IDs (marina, marcoh, daan) to their corresponding PHP class names
$characterClassMap = [
    'marina' => 'Occultist',
    'marcoh' => 'Thug',
    'daan' => 'Doctor'
];

// Base stats for character classes
$charData = [
    'Doctor' => ['hp' => 100, 'attack' => 10, 'crit' => 50, 'hit' => 80],
    'Thug' => ['hp' => 120, 'attack' => 15, 'crit' => 0, 'hit' => 50],
    'Occultist' => ['hp' => 90, 'attack' => 20, 'crit' => 30, 'hit' => 60]
];

// Helper function to handle a player's turn start actions
function startTurn(Character $player) {
    // Apply passive at the start of the player's turn
    $player->applyPassive();
}

// Helper function to check if an action is offensive (triggers counter)
function isOffensiveAction($action) {
    return in_array($action, ['attack', 'skill']);
}

// Initialize player objects to null before try block, in case init fails
$player1 = null;
$player2 = null;

// ====================================
// MAIN EXECUTION TRY/CATCH BLOCK
// ====================================
try {

    // Check if an action was passed. If not, assume it's the initial load.
    $action = $_POST['action'] ?? 'none';

    // ====================================
    // 1. CHARACTER INITIALIZATION (First Load)
    // ====================================
    if (!isset($_SESSION['player1Obj']) && $action === 'init') {
        
        // Check for required character IDs from the client's 'init' POST request
        if (empty($_POST['p1CharId']) || empty($_POST['p2CharId'])) {
            if (ob_get_length()) { ob_clean(); }
            echo json_encode(['error' => 'Initialization failed: p1CharId/p2CharId missing.']);
            exit;
        }
        
        $p1CharId = strtolower((string)$_POST['p1CharId']);
        $p2CharId = strtolower((string)$_POST['p2CharId']);

        // Map the IDs to their character classes
        $p1Class = $characterClassMap[$p1CharId] ?? 'Occultist';
        $p2Class = $characterClassMap[$p2CharId] ?? 'Doctor';
        
        // Fetch stats for initialization
        $p1Stats = $charData[$p1Class];
        $p2Stats = $charData[$p2Class];

        // Create and serialize the new character objects
        $player1 = new $p1Class("Player 1 ({$p1CharId})", $p1Stats['hp'], $p1Stats['attack'], $p1Stats['crit'], $p1Stats['hit']);
        $player2 = new $p2Class("Player 2 ({$p2CharId})", $p2Stats['hp'], $p2Stats['attack'], $p2Stats['crit'], $p2Stats['hit']);

        $_SESSION['player1Obj'] = serialize($player1);
        $_SESSION['player2Obj'] = serialize($player2);
        
        // Coin toss for the first turn (1 or 2)
        $_SESSION['turn'] = rand(1, 2);

        // Initial passive application for the starting player
        $initialPlayer = $_SESSION['turn'] === 1 ? $player1 : $player2;
        startTurn($initialPlayer);
        
        // Re-save session after applying passives
        $_SESSION['player1Obj'] = serialize($player1);
        $_SESSION['player2Obj'] = serialize($player2);

        $message = "Battle initialized! It is Player {$_SESSION['turn']}'s turn.";
        
    } else if (isset($_SESSION['player1Obj'])) { 
        // ====================================
        // 2. TURN START (Load from Session)
        // ====================================
        
        // Deserialize objects from the session
        $player1 = unserialize($_SESSION['player1Obj']);
        $player2 = unserialize($_SESSION['player2Obj']);
        
        // Determine the Attacker and Target based on the current turn
        $attackerId = $_SESSION['turn'];
        $attacker = $attackerId === 1 ? $player1 : $player2;
        $target = $attackerId === 1 ? $player2 : $player1;
        
        // Apply passive for the currently acting player
        startTurn($attacker); 

        // Re-save session immediately after applying passives
        $_SESSION['player1Obj'] = serialize($player1);
        $_SESSION['player2Obj'] = serialize($player2);
        
        $message = "Current turn: Player {$_SESSION['turn']}.";
        
        // ====================================
        // 3. ACTION HANDLING (If a POST action is received)
        // ====================================
        if ($action !== 'none' && $action !== 'init') {
            
            // --- Execute the Action ---
            switch ($action) {
                case 'attack':
                    $message = $attacker->attack($target);
                    break;

                case 'guard':
                    $message = $attacker->guard();
                    break;

                case 'skill':
                    // Check for Thug's secondary skill (Counter Stance)
                    if ($attacker instanceof Thug && 
                        isset($_POST['skillName']) && 
                        $_POST['skillName'] === $attacker->getCounterSkillName()) {
                        $message = $attacker->useCounterStance();
                    } else {
                        // Default primary skill use
                        $message = $attacker->useSkill($target);
                    }
                    break;
                    
                default:
                    $message = 'Invalid action received: ' . $action;
            }

            // --- Post-Action Logic (Counter Attack & Turn Flip) ---
            
            // 1. Counter Attack Check
            // If the target has counter status and the attacker used an offensive action
            if (!empty($target->statusEffects['counter']) && isOffensiveAction($action)) {
                // Check if the target is still alive to counter
                if ($target->isAlive()) {
                    // The counter uses the target's attack method against the attacker
                    $counterMsg = $target->attack($attacker);
                    $message .= "<br><strong>Counter!</strong><br>" . $counterMsg;
                }
                // Remove the counter status immediately after triggering
                unset($target->statusEffects['counter']);
            }
            
            // 2. Flip the turn ID
            $_SESSION['turn'] = $attackerId === 1 ? 2 : 1;
        }
    } else {
        // If not initialized and action is not 'init', or if session is corrupt
        $message = 'Error: Battle not initialized. Send "action=init" first.';
        $_SESSION['turn'] = 1; // Default to 1 for client sanity
    }

    // ====================================
    // 4. SAVE AND FINALIZE
    // ====================================

    // Determine which player object is which for serialization
    $p1_final = $player1 ?? null;
    $p2_final = $player2 ?? null;

    // Only save if objects exist (i.e., battle was successfully initialized)
    if ($p1_final && $p2_final) {
        // Serialize and save the current state of both players back to the session
        $_SESSION['player1Obj'] = serialize($p1_final);
        $_SESSION['player2Obj'] = serialize($p2_final);
    }

    $winner = '';
    // Check for winner only *after* damage has been applied
    if ($p1_final && $p2_final && (!$p1_final->isAlive() || !$p2_final->isAlive())) {
        
        // 💥 CRITICAL FIX APPLIED HERE: Use getName() instead of direct property access
        $winner = $p1_final->isAlive() ? $p1_final->getName() . " wins!" : $p2_final->getName() . " wins!";
        
        // Clear session to prepare for new game
        session_destroy();
        session_start(); // Start a new session to allow the final response to be sent
    }

    // Return JSON response
    if (ob_get_length()) { ob_clean(); } // Clean the output buffer just before sending JSON

    echo json_encode([
        'message' => $message,
        'player1_hp' => $p1_final ? $p1_final->getHealth() : 0,
        'player1_maxHp' => $p1_final ? $p1_final->getMaxHealth() : 0,
        'player2_hp' => $p2_final ? $p2_final->getHealth() : 0,
        'player2_maxHp' => $p2_final ? $p2_final->getMaxHealth() : 0,
        'turn' => $_SESSION['turn'] ?? 1,
        'winner' => $winner,
        // Provide skill names for the UI buttons
        'player1_skill' => $p1_final ? $p1_final->getSkillName() : 'N/A', 
        'player2_skill' => $p2_final ? $p2_final->getSkillName() : 'N/A',
        // Include the secondary skill for Thug, if necessary
        'player1_secondary_skill' => ($p1_final instanceof Thug) ? $p1_final->getCounterSkillName() : null,
        'player2_secondary_skill' => ($p2_final instanceof Thug) ? $p2_final->getCounterSkillName() : null,
    ]);

} catch (Throwable $e) {
    // ====================================
    // ERROR HANDLER
    // ====================================
    if (ob_get_length()) { ob_clean(); }
    error_log("BATTLE EXCEPTION: " . $e->getMessage() . "\n" . $e->getTraceAsString());
    
    echo json_encode([
        'error' => 'Server exception: ' . $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
    exit;
}
?>