<?php
abstract class Character {
    protected string $name;
    protected int $hp;
    protected int $maxHp;
    protected int $attack;
    public int $critRate;
    protected int $hitRate;
    protected bool $guarding = false;
    public array $statusEffects = [];

    public function getName(): string {
        return $this->name;
    }

    public function __construct(string $name, int $hp, int $attack, int $critRate, int $hitRate) {
        $this->name = $name;
        $this->hp = $hp;
        $this->maxHp = $hp;
        $this->attack = $attack;
        $this->critRate = $critRate;
        $this->hitRate = $hitRate;
    }

    public function isAlive(): bool { 
        return $this->hp > 0; 
    }
    
    public function getHealth(): int { 
        return $this->hp; 
    }
    
    public function getMaxHealth(): int { 
        return $this->maxHp; 
    }
    
    public function isGuarding(): bool { 
        return $this->guarding; 
    }
    
    public function stopGuard(): void { 
        $this->guarding = false; 
    }
    
    public function unGuard(): void { 
        $this->guarding = false; 
    }

    public function guard(): string {
        $this->guarding = true;
        return "{$this->name} is guarding!";
    }
    
    public function takeDamage(int $damage): void {
        $this->hp -= $damage;
        if ($this->hp < 0) $this->hp = 0;
    }

    public function attack(Character $target): string {
        if (!$target->isAlive() || !$this->isAlive()) return "";
        
        $hitChance = rand(1, 100);
        if ($hitChance > $this->hitRate) {
            return "{$this->name} attacks {$target->name} but misses!";
        }
        
        $critChance = rand(1, 100) <= $this->critRate ? 2 : 1;
        $damage = (int)($this->attack * $critChance);
        
        if ($target->isGuarding()) {
            $damage = (int)($damage * 0.75);
        }
        
        $target->takeDamage($damage);
        
        $critText = $critChance === 2 ? " (Critical!)" : "";
        return "{$this->name} attacks {$target->name} for {$damage} damage{$critText}.";
    }

    abstract public function applyPassive(): void;
    abstract public function useSkill(Character $target): string;
    abstract public function getSkillName(): string;
}
?>