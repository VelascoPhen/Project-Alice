<?php
require_once __DIR__ . '/Character.php';

/**
 * The Doctor character class.
 * Focuses on self-healing, support (Analyze buff), and precise attacks.
 */
class Doctor extends Character {
    // Passive: HP restored at the start of every turn
    private int $passiveHpGain = 3; 
    
    // Status: How many turns the Analyze buff has left
    private int $skillTurnsLeft = 0;

    // Dialogue lines for attacks that hit
    private array $hitMessages = [
        "targets a vital point for",
        "precisely strikes for",
        "inflicts a painful, calculated wound for",
        "lands a sharp hit for"
    ];

    // Dialogue lines for attacks that miss
    private array $missMessages = [
        "A shaky aim, the attack misses.",
        "The target slips away from the scalpel's edge.",
        "The pressure causes a misfire.",
        "A clean miss."
    ];

    /**
     * Applies the character's passive ability at the start of the turn.
     * Heals a small amount and decrements the skill buff timer.
     */
    public function applyPassive(): void {
        // 1. Passive Self-Heal
        if ($this->hp > 0) {
            $this->hp += $this->passiveHpGain;
            // Prevent HP from exceeding maximum
            if ($this->hp > $this->maxHp) {
                $this->hp = $this->maxHp;
            }
        }
        
        // 2. Decrement Skill Timer
        if ($this->skillTurnsLeft > 0) {
            $this->skillTurnsLeft--;
            // Check if the buff has expired on this turn's end
            if ($this->skillTurnsLeft === 0) {
                // Reset the crit rate when the timer hits zero
                $this->critRate = 50; 
            }
        }
    }

    /**
     * Executes the Doctor's skill: Analyze.
     * Buffs crit rate to 100% for 2 turns and starts the timer.
     * @return string The combat log message (HTML formatted).
     */
    public function useSkill(Character $target): string {
        // Clear Guard status if guarding (offensive action)
        if ($this->isGuarding()) {
            $this->unGuard();
        }
        
        // Set the buff duration (2 turns remain *after* this turn is over)
        $this->skillTurnsLeft = 2; 
        
        // Apply the buff
        $this->critRate = 100;
        
        return "{$this->name} uses **Analyze**! Critical rate boosted to **100%** for 2 turns.";
    }

    /**
     * Executes the Doctor's standard attack.
     * Uses the character's base stats for hit chance and damage.
     * @param Character $target The character being attacked.
     * @return string The combat log message (HTML formatted).
     */
    public function attack(Character $target): string {
        if (!$target->isAlive() || !$this->isAlive()) return "";
        
        // Clear Guard status if guarding (offensive action)
        if ($this->isGuarding()) {
            $this->unGuard();
        }
        
        $msg = "{$this->name} attacks!<br>";
        $hitDamage = 0;

        // Use the character's hitRate stat
        if (rand(1, 100) <= $this->hitRate) {
            // Attack HIT - Check for critical hit
            $isCrit = rand(1, 100) <= $this->critRate;
            
            // Calculate damage based on crit
            $baseDamage = $isCrit ? ($this->attack * 2) : $this->attack;
            
            // Apply guard reduction if target is guarding
            if ($target->isGuarding()) {
                $baseDamage = (int)round($baseDamage * 0.5);
            }
            
            $hitDamage = $baseDamage;
            $target->takeDamage($hitDamage);
            
            // Select a random hit dialogue line
            $dialogue = $this->hitMessages[array_rand($this->hitMessages)];
            $critText = $isCrit ? " **CRITICAL HIT!**" : "";
            $msg .= "The attack {$dialogue} **{$hitDamage}** damage." . $critText;
        } else {
            // Attack MISS
            $dialogue = $this->missMessages[array_rand($this->missMessages)];
            $msg .= $dialogue;
        }
        
        return $msg . "<br>";
    }

    /**
     * Gets the display name of the primary skill (Analyze).
     * @return string
     */
    public function getSkillName(): string { 
        return "Analyze"; 
    }
}
?>