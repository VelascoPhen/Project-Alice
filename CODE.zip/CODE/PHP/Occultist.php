<?php
require_once __DIR__ . '/Character.php';

/**
 * The Occultist character class.
 * Focuses on multi-hit attacks with a skill boost passive.
 */
class Occultist extends Character {
    
    // Flag to track if the initial skill boost (passive) has been used
    private bool $firstSkillBoost = true;

    // Dialogue lines for attacks that hit and deal damage
    protected array $hitMessages = [
        "lands a wicked strike for",
        "drains the target's energy for",
        "strikes a solid blow for",
        "connects and deals"
    ];

    // Dialogue lines for attacks that miss (deal 0 damage)
    protected array $missMessages = [
        "The orb fizzles out.",
        "The target narrowly avoids the blast.",
        "A spectral miss.",
        "The attack harmlessly dissipates."
    ];

    /**
     * Applies the character's passive ability.
     * Grants a one-time 'skillBoost' effect for the first skill use.
     */
    public function applyPassive(): void {
        if ($this->firstSkillBoost) {
            $this->statusEffects['skillBoost'] = true;
            $this->firstSkillBoost = false;
        }
    }

    /**
     * Executes the Occultist's standard attack (A basic spell).
     * @param Character $target The character being attacked.
     * @return string The combat log message (HTML formatted).
     */
    public function attack(Character $target): string {
        if (!$target->isAlive() || !$this->isAlive()) return "";
        
        // Clear Guard status if the Occultist was guarding
        if ($this->isGuarding()) {
            $this->unGuard();
        }

        $msg = "{$this->name} fires a basic spell.<br>";
        $hitDamage = 0;
        $hitChance = 95; // High accuracy basic attack
        $minDamage = 5;
        $maxDamage = 10;
        
        if (rand(1, 100) <= $hitChance) {
            $baseDamage = rand($minDamage, $maxDamage); 
            
            // Apply guard reduction
            if ($target->isGuarding()) {
                $baseDamage = (int)round($baseDamage * 0.5);
                $msg .= "The spell hits the **Guard**! ";
            }

            $hitDamage = $baseDamage;
            $target->takeDamage($hitDamage);
            
            $dialogue = $this->hitMessages[array_rand($this->hitMessages)];
            $msg .= "{$this->name} {$dialogue} **{$hitDamage}** damage.";
        } else {
            $dialogue = $this->missMessages[array_rand($this->missMessages)];
            $msg .= "The spell misses. {$dialogue}";
        }
        
        return $msg . "<br>";
    }

    /**
     * Executes the Occultist's primary skill, Black Orb (or Double Black Orb).
     * Applies Guard reduction and uses the base takeDamage method.
     * @param Character $target The character being attacked.
     * @return string The combat log message (HTML formatted).
     */
    public function useSkill(Character $target): string {
        // Clear Guard status if the Occultist was guarding
        if ($this->isGuarding()) {
            $this->unGuard();
        }
        
        $msg = "";
        $totalDamage = 0;
        $isBoosted = !empty($this->statusEffects['skillBoost']);

        // Set parameters based on boost status
        if ($isBoosted) {
            // --- DOUBLE BLACK ORB (Boosted) ---
            $msg .= "{$this->name} uses **Double Black Orb**!<br>";
            $hits = 6;
            $hitChance = 60; // Lower per-hit accuracy
            $minHitDamage = 1;
            $maxHitDamage = 10;
        } else {
            // --- BLACK ORB (Standard) ---
            $msg .= "{$this->name} uses **Black Orb**!<br>";
            $hits = 3;
            $hitChance = 80; // Higher per-hit accuracy
            $minHitDamage = 1;
            $maxHitDamage = 10;
        }
        
        // Loop for the multi-hit attack
        for ($i = 0; $i < $hits; $i++) {
            $hitDamage = 0;
            $hitMsg = "Hit " . ($i + 1) . ": ";
            
            // Determine if the attack hits
            if (rand(1, 100) <= $hitChance) {
                // HIT: Calculate base damage
                $baseDamage = rand($minHitDamage, $maxHitDamage); 
                
                // Guard Reduction is handled *per hit* for multi-hit attacks
                if ($target->isGuarding()) {
                    $baseDamage = (int)round($baseDamage * 0.5);
                    $hitMsg .= "Guard! ";
                }
                
                $hitDamage = $baseDamage;
                $totalDamage += $hitDamage;
                
                // Select a random hit dialogue line
                $dialogue = $this->hitMessages[array_rand($this->hitMessages)];
                $hitMsg .= "{$dialogue} **{$hitDamage}** damage.";
            } else {
                // MISS: Damage is 0
                $dialogue = $this->missMessages[array_rand($this->missMessages)];
                $hitMsg .= "{$dialogue}";
            }
            
            $msg .= $hitMsg . "<br>";
        }

        // Apply total accumulated damage to the target
        if ($totalDamage > 0) {
            $target->takeDamage($totalDamage);
        }
        
        // Remove the boost effect after the skill is used
        if ($isBoosted) {
            unset($this->statusEffects['skillBoost']); 
        }
        
        return $msg;
    }

    /**
     * Gets the display name of the main skill.
     * @return string
     */
    public function getSkillName(): string { 
        return "Black Orb"; 
    }
}
?>