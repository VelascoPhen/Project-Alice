<?php
require_once __DIR__ . '/Character.php';

/**
 * The Thug character class.
 * Inherits basic combat functionality from Character.
 * Focuses on high physical damage, moderate accuracy, and defensive counterplay.
 */
class Thug extends Character {

    // Dialogue lines for attacks that hit
    protected array $hitMessages = [
        "delivers a powerful blow for",
        "lands a solid punch for",
        "connects hard and deals",
        "brutalizes the target for"
    ];

    // Dialogue lines for attacks that miss
    protected array $missMessages = [
        "A wild swing misses.",
        "The opponent ducks the punch.",
        "The attack grazes harmlessly.",
        "A poor read, the punch whiffs."
    ];

    /**
     * Applies the character's passive ability.
     * Thug has no passive.
     */
    public function applyPassive(): void {
        // No passive applied for Thug
    }

    /**
     * Executes the Thug's standard attack (A basic strike).
     * @param Character $target The character being attacked.
     * @return string The combat log message (HTML formatted).
     */
    public function attack(Character $target): string {
        if (!$target->isAlive() || !$this->isAlive()) return "";
        
        // Clear Guard status if the Thug was guarding (offensive action)
        if ($this->isGuarding()) {
            $this->unGuard();
        }
        
        $msg = "{$this->name} performs a **basic strike**.<br>";
        $hitChance = 90; // Higher accuracy for basic attack
        $minDamage = 10;
        $maxDamage = 18;

        $hitDamage = 0;
        $hitMsg = '';
        
        if (rand(1, 100) <= $hitChance) {
            $baseDamage = rand($minDamage, $maxDamage); 
            
            // Apply guard reduction
            if ($target->isGuarding()) {
                $baseDamage = (int)round($baseDamage * 0.5);
                $hitMsg = "The strike hits the **Guard**! ";
            }

            $hitDamage = $baseDamage;
            $target->takeDamage($hitDamage);
            
            $dialogue = $this->hitMessages[array_rand($this->hitMessages)];
            $hitMsg .= "{$this->name} {$dialogue} **{$hitDamage}** damage.";
        } else {
            $dialogue = $this->missMessages[array_rand($this->missMessages)];
            $hitMsg = "The strike misses. {$dialogue}";
        }
        
        return $msg . $hitMsg . "<br>";
    }

    /**
     * Executes the Thug's primary Skill (Punch).
     * This is a stronger, but slightly less accurate, attack.
     * @param Character $target The character being attacked.
     * @return string The combat log message (HTML formatted).
     */
    public function useSkill(Character $target): string {
        // Clear Guard status if the Thug was guarding (offensive action)
        if ($this->isGuarding()) {
            $this->unGuard();
        }
        
        $msg = "{$this->name} uses **Punch**!<br>";
        $hitChance = 85; // High base hit chance for reliability
        $minDamage = 18; // Stronger damage floor
        $maxDamage = 25; // Stronger damage ceiling

        $hitDamage = 0;
        $hitMsg = '';
        
        // Determine if the attack hits
        if (rand(1, 100) <= $hitChance) {
            // HIT: Calculate base damage
            $baseDamage = rand($minDamage, $maxDamage); 
            
            // Apply guard reduction
            if ($target->isGuarding()) {
                $baseDamage = (int)round($baseDamage * 0.5);
                $hitMsg = "The attack hits the **Guard**! ";
            }

            $hitDamage = $baseDamage;
            $target->takeDamage($hitDamage);
            
            // Select a random hit dialogue line
            $dialogue = $this->hitMessages[array_rand($this->hitMessages)];
            $hitMsg .= "{$this->name} {$dialogue} **{$hitDamage}** damage.";
        } else {
            // MISS: Damage is 0
            $dialogue = $this->missMessages[array_rand($this->missMessages)];
            $hitMsg = "The attack misses. {$dialogue}";
        }
        
        return $msg . $hitMsg . "<br>";
    }

    /**
     * Activates the Thug's Counter Stance ability.
     * Applies the 'counter' status effect and the Guard status.
     * @return string The combat log message (HTML formatted).
     */
    public function useCounterStance(): string {
        // Apply the 'counter' status effect to the Thug itself
        $this->statusEffects['counter'] = true;
        
        // Also apply the guard status for damage reduction during the enemy's turn
        $this->guard();
        
        return "{$this->name} assumes **Counter Stance**! Damage reduced and ready to strike back on hit.";
    }

    /**
     * Gets the display name of the main attack skill (for UI purposes).
     * @return string
     */
    public function getSkillName(): string { 
        return "Punch"; 
    }
    
    /**
     * Gets the display name of the secondary skill (Counter Stance).
     * @return string
     */
    public function getCounterSkillName(): string { 
        return "Counter Stance"; 
    }
}
?>