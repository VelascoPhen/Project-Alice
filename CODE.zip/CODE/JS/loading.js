const BG = '/ASSETS/SFX/loading.mp3'; 

// Get the main container element for the fade-out
const loadingContainer = document.querySelector(".loading-container");

// Define the simulated time needed to "load" assets (e.g., 5 seconds)
const LOADING_TIME_MS = 5000; 

// Define the time for the fade-out effect 
const FADE_OUT_TIME_MS = 1000;

// --- Audio Functions (Remain the same, but with corrected path) ---

function setupBackgroundMusic() {
    backgroundMusic = new Audio(BG);
    backgroundMusic.loop = true;
    backgroundMusic.volume = 0.6;
}

function attemptPlayMusic() {
    if (backgroundMusic) {
        backgroundMusic.play().catch(error => {
            console.log("Autoplay prevented:", error);
            document.addEventListener('keydown', resumeMusicOnInteraction, { once: true });
            document.addEventListener('click', resumeMusicOnInteraction, { once: true });
        });
    }
}

function resumeMusicOnInteraction() {
    if (backgroundMusic && backgroundMusic.paused) {
        backgroundMusic.play().catch(error => {
            console.error("Failed to resume music after interaction:", error);
        });
    }
}

function startLoadingSequence() {
    console.log("Loading assets for the battle screen...");

    // 1. Wait for the simulated loading time to pass
    setTimeout(() => {
        
        console.log("Loading complete. Initiating fade-out.");

        // 2. Trigger the CSS fade-out effect
        if (loadingContainer) {
            loadingContainer.classList.add("fade-out");
        }

        // 3. Wait for the fade-out to finish, then redirect to the final battle page
        setTimeout(() => {
            // *** IMPORTANT: Change the path below to your actual battle page URL ***
            PageTransition.navigateTo("/CODE/HTML/dialogue.html"); 
        }, FADE_OUT_TIME_MS);

    }, LOADING_TIME_MS);
}

// Start the loading process when the page loads
startLoadingSequence();