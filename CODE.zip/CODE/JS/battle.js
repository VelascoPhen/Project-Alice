// ======================
// ASSET MAPPING
// ======================
const BATTLE_IMG_PATH = "/ASSETS/BATTLE/";

const BATTLE_SPRITES = {
    marina: { 
        player: "/ASSETS/CHARACTER ASSETS/Marina_(Player).png", 
        enemy: "/ASSETS/CHARACTER ASSETS/Marina_(Enemy).png" 
    },
    marcoh: { 
        player: "/ASSETS/CHARACTER ASSETS/Marcoh_(Player).png", 
        enemy: "/ASSETS/CHARACTER ASSETS/Marcoh_(Enemy).png" 
    },
    daan: { 
        player: "/ASSETS/CHARACTER ASSETS/Daan_(Player).png", 
        enemy: "/ASSETS/CHARACTER ASSETS/Daan_(Enemy).png" 
    }
};

// ======================
// AUDIO MAPPING
// ======================
const AUDIO_PATHS = {
    // Skill sounds (mapped by skill name)
    skills: {
        "Black Orb": "/ASSETS/SFX/occultist_skill.mp3",
        "Punch": "/ASSETS/SFX/thug_skill.mp3",
        "Counter Stance": "/ASSETS/SFX/counter_stance.mp3",
        "Analyze": "/ASSETS/SFX/doctor_skill.mp3"
    },
    // Death sound
    death: "/ASSETS/SFX/death.mp3",
    // Background music pool (randomly selected at battle start)
    bgMusic: [
        "/ASSETS/BATTLE/battle_theme_1.mp3", 
        "/ASSETS/BATTLE/battle_theme_2.mp3",
        "/ASSETS/BATTLE/battle_theme_3.mp3",
        "/ASSETS/BATTLE/battle_theme_4.mp3",
        "/ASSETS/BATTLE/battle_theme_5.mp3"
    ]
};

// Background music instance
let bgMusicAudio = null;

// Helper function to play audio
function playAudio(audioPath) {
    if (!audioPath) return;
    
    const audio = new Audio(audioPath);
    audio.volume = 0.5; // Adjust volume (0.0 to 1.0)
    audio.play().catch(err => console.warn("Audio playback failed:", err));
}

// Helper function to play background music
function playRandomBGMusic() {
    // Stop any existing background music
    if (bgMusicAudio) {
        bgMusicAudio.pause();
        bgMusicAudio = null;
    }
    
    // Select a random track from the pool
    const randomIndex = Math.floor(Math.random() * AUDIO_PATHS.bgMusic.length);
    const selectedTrack = AUDIO_PATHS.bgMusic[randomIndex];
    
    // Create and play the audio
    bgMusicAudio = new Audio(selectedTrack);
    bgMusicAudio.volume = 0.3; // Lower volume for background music
    bgMusicAudio.loop = true; // Loop the music (Confirmed working logic)
    
    bgMusicAudio.play().catch(err => {
        // Updated warning to reflect common issue
        console.warn(`Background music playback failed for ${selectedTrack}. This is often due to Autoplay restriction or incorrect file path.`, err);
    });
    
    console.log(`Playing background music: ${selectedTrack}`);
}

// Helper function to stop background music
function stopBGMusic() {
    if (bgMusicAudio) {
        bgMusicAudio.pause();
        bgMusicAudio = null;
    }
}

// ======================
// DOM REFERENCES
// ======================
const background = document.getElementById("background");
const banner = document.getElementById("turnBanner");
const hpCurrentEl = document.getElementById("hpCurrent");
const hpMaxEl = document.getElementById("hpMax");
const hpBarFill = document.getElementById("hpBar");
const messageText = document.getElementById("messageText");
const skillButtons = document.querySelectorAll(".skill-btn");
const player1SpriteEl = document.getElementById("player1Sprite");
const player2SpriteEl = document.getElementById("player2Sprite");
const endGameOverlay = document.getElementById("endGameOverlay");
const endGamePopup = document.getElementById("endGamePopup");

// ======================
// INITIAL STYLING FOR FADE
// ======================
[background, banner, player1SpriteEl, player2SpriteEl].forEach(el => {
    el.style.transition = "opacity 1s ease-in-out";
    el.style.opacity = 0;
});

// ======================
// LOAD BACKGROUND
// ======================
const selectedBG = localStorage.getItem("selectedBG") || "/ASSETS/BG/cliff1_night.png";

function loadBattleBG() {
    background.style.backgroundImage = `url('${selectedBG}')`;
    background.style.backgroundSize = "cover";
    background.style.backgroundPosition = "center";

    setTimeout(() => {
        background.style.opacity = 1;
        banner.style.opacity = 1;
        player1SpriteEl.style.opacity = 1;
        player2SpriteEl.style.opacity = 1;
    }, 100);
}

// ======================
// LOAD PLAYER DATA
// ======================
const p1CharId = localStorage.getItem("p1Character") || "marina";
const p2CharId = localStorage.getItem("p2Character") || "daan";

const p1SpriteData = BATTLE_SPRITES[p1CharId] || BATTLE_SPRITES.marina;
const p2SpriteData = BATTLE_SPRITES[p2CharId] || BATTLE_SPRITES.daan;

const p1Name = localStorage.getItem("player1") || p1CharId;
const p2Name = localStorage.getItem("player2") || p2CharId;

// ======================
// BATTLE STATE
// ======================
const state = {
    currentPlayer: 1,
    players: {
        1: { name: p1Name, hp: 0, maxHp: 0 }, 
        2: { name: p2Name, hp: 0, maxHp: 0 }
    }
};

let battleInitialized = false;

// ======================
// SPRITE HELPERS
// ======================
function updateSpritesForTurn() {
    [player1SpriteEl, player2SpriteEl].forEach(el =>
        el.classList.remove("left-slot", "right-slot", "active-turn", "inactive-turn")
    );

    if (state.currentPlayer === 1) {
        player1SpriteEl.src = p1SpriteData.player;
        player2SpriteEl.src = p2SpriteData.enemy;

        player1SpriteEl.classList.add("left-slot", "active-turn");
        player2SpriteEl.classList.add("right-slot", "inactive-turn");
    } else {
        player2SpriteEl.src = p2SpriteData.player;
        player1SpriteEl.src = p1SpriteData.enemy;

        player2SpriteEl.classList.add("left-slot", "active-turn");
        player1SpriteEl.classList.add("right-slot", "inactive-turn");
    }
}

// ======================
// UI HELPERS
// ======================

function updateHPBar() {
    const activePlayerId = state.currentPlayer;
    const p = state.players[activePlayerId];
    
    const percentage = p.maxHp > 0 ? (p.hp / p.maxHp) * 100 : 0;

    hpCurrentEl.textContent = p.hp;
    hpMaxEl.textContent = p.maxHp;

    hpBarFill.style.width = `${percentage}%`;
    
    hpBarFill.classList.remove('low-hp', 'critical-hp');
    if (percentage < 30) {
        hpBarFill.classList.add('low-hp');
    }
    if (percentage < 10) {
        hpBarFill.classList.add('critical-hp');
    }
}

function updateUI(data = null) {
    updateSpritesForTurn(); 
    updateHPBar();
    // Use the player's name for the turn banner
    banner.textContent = `${state.players[state.currentPlayer].name}'s Turn`; 
    
    if (data) {
        const activePlayerObj = state.players[state.currentPlayer];
        const skillName = (state.currentPlayer === 1) ? data.player1_skill : data.player2_skill;
        const secondarySkillName = (state.currentPlayer === 1) ? data.player1_secondary_skill : data.player2_secondary_skill;

        const mainSkillButton = Array.from(skillButtons).find(btn => btn.dataset.skill === 'skill');
        if (mainSkillButton) {
            mainSkillButton.textContent = skillName;
        }

        // Handle secondary skill button for Thug (Counter Stance)
        const secondarySkillButton = Array.from(skillButtons).find(btn => btn.dataset.skill === 'secondary');
        if (secondarySkillButton) {
            if (secondarySkillName) {
                secondarySkillButton.textContent = secondarySkillName;
                secondarySkillButton.style.display = 'inline-block';
            } else {
                secondarySkillButton.style.display = 'none';
            }
        }
    }
}

// ======================
// END GAME UI (Fixed)
// ======================

function displayEndGameOptions(winnerName) {
    // Stop background music
    stopBGMusic();

    // Play death sound
    playAudio(AUDIO_PATHS.death);

    // Disable action buttons 
    skillButtons.forEach(b => b.disabled = true);
    
    // Optional: Update text to announce the result in the dialogue box too
    messageText.innerHTML = `<span style="color: #ff5555">${winnerName} has won the battle!</span>`;

    // Clear any previous popup content
    endGamePopup.innerHTML = '';

    // Title for the popup
    const title = document.createElement('h2');
    title.innerHTML = `<strong style="color:#d4af37; text-shadow: 0 0 5px #ff0000;">${winnerName} wins!</strong>`; 
    endGamePopup.appendChild(title);

    const optionsContainer = document.createElement('div');
    optionsContainer.id = 'endGameOptions';
    optionsContainer.style.marginTop = '15px';
    optionsContainer.style.display = 'flex';
    optionsContainer.style.flexDirection = 'column';
    optionsContainer.style.gap = '10px';
    optionsContainer.style.alignItems = 'center';

    const options = [
        { 
            text: 'Restart Game', 
            description: 'Play again with the same characters',
            action: () => window.location.reload() 
        },
        { 
            text: 'Character Selection', 
            description: 'Choose different characters',
            action: () => window.location.href = '/CODE/HTML/character_selection.html' 
        },
        { 
            text: 'Main Menu', 
            description: 'Return to main menu',
            action: () => window.location.href = '/CODE/HTML/main_menu.html' 
        }
    ];

    options.forEach(opt => {
        const buttonWrapper = document.createElement('div');
        buttonWrapper.style.textAlign = 'center';

        const button = document.createElement('button');
        button.textContent = opt.text;
        button.className = 'skill-btn'; 
        button.addEventListener('click', opt.action);

        const description = document.createElement('small');
        description.textContent = opt.description;
        description.style.display = 'block';
        description.style.marginTop = '5px';
        description.style.color = '#999';
        description.style.fontSize = '12px';

        buttonWrapper.appendChild(button);
        buttonWrapper.appendChild(description);
        optionsContainer.appendChild(buttonWrapper);
    });

    endGamePopup.appendChild(optionsContainer);

    // Show the overlay
    endGameOverlay.style.display = 'flex';
}
// ======================
// SKILL BUTTON HANDLERS
// ======================

skillButtons.forEach(btn => {
    btn.addEventListener("click", async () => {
        if (!battleInitialized) {
            messageText.textContent = 'Battle not ready yet...';
            return;
        }

        const action = btn.dataset.skill.toLowerCase();
        const skillName = btn.textContent.trim(); // Get the skill name from button text

        skillButtons.forEach(b => b.disabled = true);

        try {
            // Build the request body
            let body = `action=${encodeURIComponent(action)}`;
            
            // For skill and secondary actions, include the skill name
            if (action === 'skill' || action === 'secondary') {
                body += `&skillName=${encodeURIComponent(skillName)}`;
            }

            const response = await fetch('/CODE/PHP/battle.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: body
            });

            const text = await response.text();
            let data;

            try {
                data = JSON.parse(text);
            } catch {
                console.error("Server response was not valid JSON:", text);
                messageText.textContent = 'Server error - check console';
                skillButtons.forEach(b => b.disabled = false);
                return;
            }

            if (data.error) {
                messageText.innerHTML = `<span style="color:#d00;">Error:</span> ${data.error}`;
                skillButtons.forEach(b => b.disabled = false);
                return;
            }

            // Play skill audio if it was a skill action
            if ((action === 'attack' || action === 'skill' || action === 'secondary') && AUDIO_PATHS.skills[skillName]) {
                 // Check if it's the specific skill 'Punch' which is an attack
                 if (action === 'attack' && skillName === 'Punch') {
                     playAudio(AUDIO_PATHS.skills['Punch']);
                 } else if (AUDIO_PATHS.skills[skillName]) {
                     playAudio(AUDIO_PATHS.skills[skillName]);
                 }
            }


            messageText.innerHTML = data.message || "Action complete.";

            // Store previous HP to detect death
            const prevP1HP = state.players[1].hp;
            const prevP2HP = state.players[2].hp;

            state.players[1].hp = data.player1_hp;
            state.players[1].maxHp = data.player1_maxHp;
            state.players[2].hp = data.player2_hp;
            state.players[2].maxHp = data.player2_maxHp;

            state.currentPlayer = data.turn;

            // Check if someone just died (HP went to 0)
            if ((prevP1HP > 0 && data.player1_hp === 0) || (prevP2HP > 0 && data.player2_hp === 0)) {
                // Death detected - play death sound
                playAudio(AUDIO_PATHS.death);
            }

            updateUI(data); 

            if (data.winner) {
                displayEndGameOptions(data.winner);
                return;
            }

            skillButtons.forEach(b => b.disabled = false);

        } catch (error) {
            console.error("Network error:", error);
            messageText.textContent = 'Network error - check console';
            skillButtons.forEach(b => b.disabled = false);
        }
    });
});

// ======================
// INITIALIZATION
// ======================

async function initializeBattle() {
    try {
        messageText.textContent = 'Initializing battle...';

        const response = await fetch('/CODE/PHP/battle.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=init&p1CharId=${p1CharId}&p2CharId=${p2CharId}`
        });

        const text = await response.text();
        let data;

        try {
            data = JSON.parse(text);
        } catch {
            console.error("Init response was not valid JSON:", text);
            messageText.innerHTML = 'Server error - invalid response<br><small>Check console</small>';
            return;
        }

        if (data.error) {
            messageText.innerHTML = `<span style="color:#d00;">Init Error:</span> ${data.error}`;
            return;
        }

        state.players[1].hp = data.player1_hp;
        state.players[1].maxHp = data.player1_maxHp;
        state.players[2].hp = data.player2_hp;
        state.players[2].maxHp = data.player2_maxHp;
        state.currentPlayer = data.turn;

        battleInitialized = true;

        updateUI(data);
        messageText.textContent = `${state.players[data.turn].name}'s turn. Select a skill.`;

    } catch (error) {
        console.error("Initialization error:", error);
        messageText.innerHTML = 'Failed to initialize battle<br><small>Check console</small>';
    }
}

// ======================
// START EVERYTHING (Final fix for robust Autoplay)
// ======================

// Flag to ensure music function only runs once
let musicStarted = false; 

// Function to handle the first user interaction and start music
function handleFirstInteraction() {
    if (!musicStarted) {
        playRandomBGMusic();
        musicStarted = true;
        
        // Remove listeners once music is started 
        document.removeEventListener("mousedown", handleFirstInteraction);
        document.removeEventListener("touchstart", handleFirstInteraction);
        document.removeEventListener("keydown", handleFirstInteraction);
        
        console.log("Music auto-start successfully enabled by user interaction.");
    }
}

document.addEventListener("DOMContentLoaded", () => {
    loadBattleBG();
    updateSpritesForTurn();
    initializeBattle();

    document.addEventListener("mousedown", handleFirstInteraction, { once: true });
    document.addEventListener("touchstart", handleFirstInteraction, { once: true });
    document.addEventListener("keydown", handleFirstInteraction, { once: true });

    setTimeout(() => {
        document.body.style.opacity = 1;
    }, 100);
});