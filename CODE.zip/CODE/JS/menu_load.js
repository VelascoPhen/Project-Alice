document.addEventListener('DOMContentLoaded', () => {
    const typewriterEl = document.getElementById('typewriter');
    const continueText = document.getElementById('continueText');
    const logo = document.getElementById('logo');
    const introContainer = document.querySelector('.intro-container');

    const glitchSound = document.getElementById('glitchSound');
    const enterSound = document.getElementById('enterSound');

    let audioEnabled = false;

    // Enable audio on first interaction
    function enableAudio() {
        if (!audioEnabled) {
            glitchSound.muted = false;
            glitchSound.play().catch(() => {});
            enterSound.muted = false;
            audioEnabled = true;

            document.removeEventListener('keydown', enableAudio);
            document.removeEventListener('click', enableAudio);
        }
    }

    document.addEventListener('keydown', enableAudio, { once: true });
    document.addEventListener('click', enableAudio, { once: true });

    // Fade in logo
    logo.style.opacity = 1;

    // Typewriter Effect
    const typeText = "are you ready?";
    let index = 0;
    function typeWriter() {
        if (index < typeText.length) {
            typewriterEl.textContent += typeText.charAt(index);
            index++;
            setTimeout(typeWriter, 120);
        } else {
            showContinueText();
        }
    }

    // Show "Press any key" with fade-in
    function showContinueText() {
        continueText.classList.remove('hidden');
        continueText.classList.add('visible');
        continueText.style.opacity = 0;
        continueText.style.transition = "opacity 1.2s ease-in";
        setTimeout(() => continueText.style.opacity = 1, 50);

        // Single keydown listener with once: true to prevent duplicates
        const handleKeyPress = () => {
            if (audioEnabled) enterSound.play();

            // Fade out intro container
            introContainer.style.transition = "opacity 1s ease";
            introContainer.style.opacity = 0;

            setTimeout(() => {
                PageTransition.navigateTo('/CODE/HTML/main_menu.html');
            }, 1000);
        };

        document.addEventListener('keydown', handleKeyPress, { once: true });
    }

    typeWriter();

    // --- Background particle animation ---
    const canvas = document.getElementById('bgCanvas');
    const ctx = canvas.getContext('2d');
    let particles = [];

    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    class Particle {
        constructor() { this.reset(); }
        reset() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 2 + 1;
            this.speedX = (Math.random() - 0.5) * 1;
            this.speedY = (Math.random() - 0.5) * 1;
            this.alpha = Math.random() * 0.5;
        }
        update() {
            this.x += this.speedX;
            this.y += this.speedY;
            if(this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) this.reset();
        }
        draw() {
            ctx.fillStyle = `rgba(255,255,255,${this.alpha})`;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI*2);
            ctx.fill();
        }
    }

    for(let i=0; i<100; i++) particles.push(new Particle());

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => { p.update(); p.draw(); });
        requestAnimationFrame(animate);
    }
    animate();
});


