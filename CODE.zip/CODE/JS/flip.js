// --- AUDIO Definitions ---
// CORRECTED PATH for background music
const AUDIO_SRC = '/ASSETS/SONGS/flip.mp3'; 
// ASSUMED PATH for sound effect (Adjust if incorrect)
const COIN_FLIP_SFX = '/ASSETS/SFX/coinflip.mp3'; 

let backgroundMusic = null;
// -------------------------------------------------------------------

const sequence = [
    "WELCOME, LOST LAMBS...",
    "DO YOU KNOW THE RULE OF COIN FLIP?",
    "YOU BOTH MUST HAVE KNOWN.",
    "THEN... DECIDE.",
    "HEADS?",
    "OR",
    "TAILS.",
    "FLIP THE COIN.",
    "COIN_FLIP_PHASE", // triggers coin flip animation
    "IT’S BEEN DECIDED.",
    "GOODLUCK"
];

// --- GIF Definitions ---
const GIF_HEADS_WINS = '/ASSETS/ADS/fear-and-hunger-coin-toss (1).gif';
const GIF_TAILS_WINS = '/ASSETS/ADS/fear-and-hunger-coin-toss.gif';
// -------------------------------------------------------------------

// Get DOM elements
const textEl = document.getElementById("fadeText");
const coinEl = document.getElementById("coin");
const screen = document.getElementById("screen");

let index = 0;
let coinFlipTriggered = false;


// --- MODAL ELEMENT REFERENCES (REQUIRED FOR THE NEW LOGIC) ---
const modalBackdrop = document.getElementById('fh-modal-backdrop');
const modalMessage = document.getElementById('fh-modal-message');
const modalConfirmBtn = document.getElementById('fh-modal-confirm');
const modalCancelBtn = document.getElementById('fh-modal-cancel');
const modalTitle = document.getElementById('fh-modal-title');


// --- Re-using and adjusting previous Modal Functions ---

/**
 * Custom alert modal to replace window.alert.
 */
function fhAlert(message, title = "[ STATUS ]") {
    // This is the standard simple alert function (used for PLEDGE ACCEPTED, etc.)
    return new Promise(resolve => {
        
        if (!modalBackdrop || !modalMessage || !modalConfirmBtn || !modalTitle) {
            window.alert(message); resolve(); return;
        }

        modalMessage.textContent = message;
        modalTitle.textContent = title;
        // Ensure cancel button is hidden for standard alerts
        if (modalCancelBtn) modalCancelBtn.style.display = 'none'; 
        modalConfirmBtn.textContent = "CONTINUE";

        const cleanup = () => {
            modalConfirmBtn.removeEventListener('click', handleConfirm);
            if (modalCancelBtn) modalCancelBtn.style.display = 'inline-block'; // Restore default state
            modalConfirmBtn.textContent = "ACCEPT"; // Restore default state
            modalTitle.textContent = "[ SELECTION ]"; // Restore default
            modalBackdrop.classList.add('modal-hidden');
            resolve();
        };

        const handleConfirm = () => cleanup();

        modalConfirmBtn.addEventListener('click', handleConfirm);
        modalBackdrop.classList.remove('modal-hidden');
    });
}


// --- Audio Functions (Remain the same, but with corrected path) ---

function setupBackgroundMusic() {
    backgroundMusic = new Audio(AUDIO_SRC);
    backgroundMusic.loop = true;
    backgroundMusic.volume = 0.6;
}

function attemptPlayMusic() {
    if (backgroundMusic) {
        backgroundMusic.play().catch(error => {
            console.log("Autoplay prevented:", error);
            document.addEventListener('keydown', resumeMusicOnInteraction, { once: true });
            document.addEventListener('click', resumeMusicOnInteraction, { once: true });
        });
    }
}

function resumeMusicOnInteraction() {
    if (backgroundMusic && backgroundMusic.paused) {
        backgroundMusic.play().catch(error => {
            console.error("Failed to resume music after interaction:", error);
        });
    }
}

function playCoinFlipSound() {
    const sfx = new Audio(COIN_FLIP_SFX);
    sfx.volume = 1.0;
    sfx.play().catch(error => {
        console.error("Failed to play coin flip sound:", error);
    });
}


/**
 * Executes the main text sequence.
 */
function playSequence() {
    attemptPlayMusic();

    if (index >= sequence.length) return;

    const text = sequence[index];

    // Ensure modal is hidden for all normal text steps
    if (modalBackdrop) {
        modalBackdrop.classList.add("modal-hidden");
    }

    // ---- COIN FLIP PHASE Trigger (REVERTED TO BUTTON/MODAL TRIGGER) ----
    if (text === "COIN_FLIP_PHASE") {
        
        // 1. Setup the custom modal for button prompt
        if (!modalBackdrop || !modalMessage || !modalConfirmBtn || !modalTitle) return; // Fail safe
        
        modalTitle.textContent = "[ DECISION ]";
        modalMessage.textContent = "Ready to face your fate? Press the button below.";
        
        // Show confirm button, hide cancel button
        modalConfirmBtn.textContent = "FLIP THE COIN"; // Custom label for the button
        if (modalConfirmBtn) modalConfirmBtn.style.display = 'inline-block';
        if (modalCancelBtn) modalCancelBtn.style.display = 'none';

        modalBackdrop.classList.remove("modal-hidden"); // Show the styled prompt

        coinFlipTriggered = false; // Reset trigger state
        
        // 2. Wait for button click (using promise/event listener)
        const handleFlipTrigger = () => {
            if (!coinFlipTriggered) {
                coinFlipTriggered = true;
                
                // 3. Cleanup and start flip
                
                // Restore modal button settings
                if (modalConfirmBtn) modalConfirmBtn.textContent = "ACCEPT";
                if (modalCancelBtn) modalCancelBtn.style.display = 'inline-block';
                
                // Hide modal
                modalBackdrop.classList.add("modal-hidden");
                
                // Remove listener after triggered
                modalConfirmBtn.removeEventListener('click', handleFlipTrigger);


                // --- Trigger the Coin Flip Sound ---
                playCoinFlipSound(); 

                setTimeout(() => {
                    startCoinFlip();
                }, 1500);
            }
        };
        
        // Attach listener ONLY to the confirm button
        modalConfirmBtn.addEventListener('click', handleFlipTrigger);
        return; 
    }

    // ---- Normal Text Fade Sequence ----
    textEl.textContent = text;
    textEl.classList.add("show");

    // Fade out after 3.0 seconds
    setTimeout(() => {
        textEl.classList.remove("show");

        // Wait for fade-out to complete (1.5 seconds)
        setTimeout(() => {
            index++;
            playSequence();
        }, 1500); 

    }, 3000); 
}

/**
 * Executes the coin flip animation and determines the result using GIFs.
 */
function startCoinFlip() {
    // Random HEADS or TAILS determination
    const result = Math.random() < 0.5 ? "HEADS" : "TAILS";
    
    // Choose the correct GIF based on the result
    const selectedGif = (result === "HEADS") ? GIF_HEADS_WINS : GIF_TAILS_WINS;
    
    // FIX FOR DOUBLE PLAY: Clear the src before setting it to force a reload
    coinEl.src = ""; 
    
    // Set the source and show the coin, starting the GIF animation (plays once)
    coinEl.src = selectedGif;
    coinEl.style.opacity = "1";
    
    // Coin flip duration (0.4 seconds). This tells us when the GIF is expected to stop.
    const FLIP_DURATION = 3800; 

    // 1. Wait for the flip to finish (400ms)
    setTimeout(() => {
        // Stop GIF from looping by replacing with static image
        const canvas = document.createElement('canvas');
        canvas.width = coinEl.width;
        canvas.height = coinEl.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(coinEl, 0, 0);
        const staticImage = canvas.toDataURL();
        
        // Replace GIF with static frame
        coinEl.src = staticImage;
        
        // 2. WAIT FOR THE DRAMATIC PAUSE (2500ms) before declaring the winner
        setTimeout(() => { 

            let winnerText;
            if (result === "HEADS") {
                winnerText = "HEADS WINS. PLAYER 1 ATTACKS FIRST";
            } else {
                winnerText = "TAILS WINS. PLAYER 2 ATTACKS FIRST";
            }

            // Show result text (overlaying the still GIF)
            textEl.textContent = winnerText;
            textEl.classList.add("show");

            // 3. Wait for result display (3.0 seconds), then clean up and proceed
            setTimeout(() => {
                textEl.classList.remove("show");
                
                // --- STOP MUSIC BEFORE REDIRECT ---
                if (backgroundMusic) {
                    backgroundMusic.pause();
                    backgroundMusic.currentTime = 0;
                }

                // Hide the coin (the GIF) only AFTER the text fades out
                coinEl.style.opacity = "0"; 

                // Wait for fade-out to complete (1.5 seconds)
                setTimeout(() => {
                    // --- REDIRECT TO LOADING SCREEN HERE ---
                    PageTransition.navigateTo("/CODE/HTML/loading.html");
                }, 1500); 

            }, 3000); 

        }, 2500); 

    }, FLIP_DURATION); // Coin flip duration
}

// 1. Setup the audio element
setupBackgroundMusic();

// 2. Start the sequence when the script loads
playSequence();