const p1Screen = document.getElementById("player1-screen");
const p2Screen = document.getElementById("player2-screen");
const p1Input = document.getElementById("player1-input");
const p2Input = document.getElementById("player2-input");

// On page load
window.addEventListener('DOMContentLoaded', () => {
    document.body.classList.add('fade-in'); // fade in full page
});

// When moving to next page
function transitionToNextPage(url) {
    PageTransition.navigateTo(url);
}

// Fade helpers
function fadeOut(el, duration = 500) {
    el.style.transition = `opacity ${duration}ms ease`;
    el.style.opacity = 0;
    return new Promise(resolve => setTimeout(resolve, duration));
}

function fadeIn(el, duration = 500) {
    el.style.opacity = 0;
    el.style.display = "block";
    el.style.transition = `opacity ${duration}ms ease`;
    setTimeout(() => {
        el.style.opacity = 1;
    }, 20);
    return new Promise(resolve => setTimeout(resolve, duration));
}

// Function to show "Let the chaos begin" message
function showChaosMessage() {
    return new Promise(resolve => {
        const msg = document.createElement("div");
        msg.textContent = "Let the chaos begin";
        msg.style.position = "fixed";
        msg.style.top = "50%";
        msg.style.left = "50%";
        msg.style.transform = "translate(-50%, -50%)";
        msg.style.fontFamily = "'Cinzel', serif";
        msg.style.fontSize = "2rem";
        msg.style.color = "#fff";
        msg.style.textAlign = "center";
        msg.style.opacity = 0;
        msg.style.transition = "opacity 1s ease";
        msg.style.zIndex = 999;
        document.body.appendChild(msg);

        setTimeout(() => msg.style.opacity = 1, 50); // fade in
        setTimeout(() => {
            msg.style.opacity = 0; // fade out
            setTimeout(() => {
                msg.remove();
                resolve();
            }, 1000);
        }, 1500); // show for 1.5s before fading out
    });
}

// --- Player 1 → Player 2 ---
p1Input.addEventListener("keydown", async (e) => {
    if (e.key === "Enter" && p1Input.value.trim() !== "") {
        localStorage.setItem("player1", p1Input.value.trim());
        await fadeOut(p1Screen, 500);
        p1Screen.classList.add("hidden");
        p2Screen.classList.remove("hidden");
        await fadeIn(p2Screen, 500);
        setTimeout(() => p2Input.focus(), 300);
    }
});

// --- Player 2 → Next Step ---
p2Input.addEventListener("keydown", async (e) => {
    if (e.key === "Enter" && p2Input.value.trim() !== "") {
        localStorage.setItem("player2", p2Input.value.trim());

        // Fade out P2 screen
        await fadeOut(p2Screen, 500);
        p2Screen.classList.add("hidden");

        // Show "Let the chaos begin" message
        await showChaosMessage();
        transitionToNextPage("/CODE/HTML/character_selection.html");
        
    }
});