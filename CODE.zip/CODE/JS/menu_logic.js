document.addEventListener('DOMContentLoaded', () => {
    const menuItems = document.querySelectorAll('.menu-item');
    const body = document.body;

    // --- PAGE FADE-IN ---
    body.style.opacity = 0;
    body.style.transition = 'opacity 1.2s ease';
    requestAnimationFrame(() => {
        body.style.opacity = 1; // fade in on load
    });

    // --- MENU ITEMS FADE-IN ---
    menuItems.forEach((item, index) => {
        item.style.opacity = 0; // start hidden
        item.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
        item.style.transform = 'translateY(20px)'; // slight drop effect

        // stagger fade-in for each item
        setTimeout(() => {
            item.style.opacity = 1;
            item.style.transform = 'translateY(0)';
        }, 200 * index);
    });

    // --- MENU ITEM CLICK HANDLER WITH FADE-OUT ---
    menuItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const action = item.dataset.action;

            switch(action) {
                case "start":
                    PageTransition.navigateTo("/CODE/HTML/start.html");
                    break;

                case "credits":
                    PageTransition.navigateTo("/CODE/HTML/credits.html");
                    break;

                case "exit":
                    window.close();
                    break;

                default:
                    alertBox("Action not implemented.");
            }
        });
    });
});

/* Custom alert box */
function alertBox(message) {
    let box = document.createElement('div');
    box.style.cssText = `
        position: fixed;
        top: 50%; left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(10, 0, 0, 0.9);
        border: 2px solid #550000;
        padding: 20px;
        border-radius: 10px;
        z-index: 200;
        color: white;
        font-family: 'Cinzel', serif;
        font-size: 1.2rem;
        box-shadow: 0 0 20px #ff000055;
        text-align: center;
        opacity: 0;
        transition: opacity 0.5s ease;
    `;
    box.textContent = message;
    document.body.appendChild(box);
    setTimeout(() => {
        box.style.opacity = 1;
    }, 50);
    setTimeout(() => box.remove(), 3000);
}
