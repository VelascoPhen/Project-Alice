// Load Player Names
const player1Name = localStorage.getItem("player1") || "PLAYER 1";
const player2Name = localStorage.getItem("player2") || "PLAYER 2";

document.getElementById("p1-username").textContent = player1Name;
document.getElementById("p2-username").textContent = player2Name;

// ====================================
// CHARACTER DATA
// ====================================
const characters = {
    1: {
        key: 'marina',
        name: "Marina",
        img: "/ASSETS/CHARACTER ASSETS/Marina_portrait.png",
        stats: "Marina excels in the occult arts, wielding unique buffs and otherworldly effects rather than brute force. Her key abilities revolve around runic engravings that provide permanent stat boosts."
    },
    2: {
        key: 'marcoh',
        name: "Marcoh",
        img: "/ASSETS/CHARACTER ASSETS/Marcoh_portrait.png",
        stats: "Marcoh is a versatile fighter who balances offense and defense. Skilled in handling heavy weaponry, he can sustain the team through crowd control and protective maneuvers."
    },
    3: {
        key: 'daan',
        name: "Daan",
        img: "/ASSETS/CHARACTER ASSETS/Daan_portrait.png",
        stats: "Daan is a cerebral and adaptable character, highly proficient in the medical arts and field surgery. He can perform emergency triage and healing with high efficiency."
    }
};

// ====================================
// SELECTION STATE
// ====================================
let playerTurn = 1;
let chosenCharacters = {};

/**
 * Custom alert modal to replace window.alert.
 * Uses the same HTML structure as fhConfirm.
 * @param {string} message - The message to display.
 */
function fhAlert(message) {
    return new Promise(resolve => {
        const modal = document.getElementById('fh-modal-backdrop');
        const messageElement = document.getElementById('fh-modal-message');
        const confirmBtn = document.getElementById('fh-modal-confirm');
        const cancelBtn = document.getElementById('fh-modal-cancel');
        const titleElement = document.getElementById('fh-modal-title');

        // Set the message
        messageElement.textContent = message;
        
        // Use an alert-specific title, then restore confirm title on cleanup
        titleElement.textContent = "[ STATUS ]"; 

        // Temporarily hide the 'Repudiate' button for an alert
        if (cancelBtn) cancelBtn.style.display = 'none';

        // Function to clean up and hide the modal
        const cleanup = () => {
            if (confirmBtn) confirmBtn.removeEventListener('click', handleConfirm);
            if (cancelBtn) cancelBtn.style.display = 'inline-block'; // Restore cancel button
            if (titleElement) titleElement.textContent = "[ SELECTION ]"; // Restore confirm title
            if (modal) modal.classList.add('modal-hidden');
            resolve();
        };

        // Handler
        const handleConfirm = () => cleanup();

        // Check if elements exist before showing
        if (!modal || !messageElement || !confirmBtn) {
            console.error("F&H Modal elements missing from DOM. Falling back to native alert.");
            window.alert(message);
            resolve();
            return;
        }

        // Attach listener (confirm button acts as 'OK')
        confirmBtn.addEventListener('click', handleConfirm);

        // Show the modal
        modal.classList.remove('modal-hidden');
    });
}

/**
 * Custom promise-based confirmation modal to replace window.confirm.
 * @param {string} message - The message to display.
 * @returns {Promise<boolean>} Resolves to true for confirm, false for cancel.
 */
function fhConfirm(message) {
    return new Promise(resolve => {
        const modal = document.getElementById('fh-modal-backdrop');
        const messageElement = document.getElementById('fh-modal-message');
        const confirmBtn = document.getElementById('fh-modal-confirm');
        const cancelBtn = document.getElementById('fh-modal-cancel');
        const titleElement = document.getElementById('fh-modal-title');


        // Set the message
        messageElement.textContent = message;
        titleElement.textContent = "[ SELECTION ]";

        // Function to clean up and hide the modal
        const cleanup = (result) => {
            if (confirmBtn) confirmBtn.removeEventListener('click', handleConfirm);
            if (cancelBtn) cancelBtn.removeEventListener('click', handleCancel);
            if (modal) modal.classList.add('modal-hidden');
            resolve(result);
        };

        // Handlers
        const handleConfirm = () => cleanup(true);
        const handleCancel = () => cleanup(false);

        // Check for required elements
        if (!modal || !messageElement || !confirmBtn || !cancelBtn || !titleElement) {
            console.error("F&H Modal elements missing from DOM. Falling back to native confirm.");
            const fallbackResult = window.confirm(message);
            resolve(fallbackResult);
            return;
        }

        // Attach listeners
        confirmBtn.addEventListener('click', handleConfirm);
        cancelBtn.addEventListener('click', handleCancel);

        // Show the modal
        modal.classList.remove('modal-hidden');
    });
}


// ====================================
// HOVER PREVIEW FUNCTIONALITY
// ====================================
/**
 * Displays character preview based on whose turn it is
 */
function showCharacterPreview(charId) {
    const char = characters[charId];
    
    if (playerTurn === 1) {
        // Show preview on left panel (Player 1's side)
        const p1Img = document.getElementById("p1-character-img");
        p1Img.src = char.img;
        p1Img.classList.remove("hidden");
        
        document.getElementById("p1-stats-text").innerHTML = char.stats;
        document.getElementById("p1-ui").classList.remove("hidden");
    } else {
        // Show preview on right panel (Player 2's side)
        const p2Img = document.getElementById("p2-character-img");
        p2Img.src = char.img;
        p2Img.classList.remove("hidden");
        
        document.getElementById("p2-stats-text").innerHTML = char.stats;
        document.getElementById("p2-ui").classList.remove("hidden");
    }
}

/**
 * Hides character preview when not hovering (only if not selected)
 */
function hideCharacterPreview() {
    if (playerTurn === 1) {
        // Only hide if player 1 hasn't selected yet
        if (!chosenCharacters.player1) {
            document.getElementById("p1-character-img").classList.add("hidden");
            document.getElementById("p1-ui").classList.add("hidden");
        }
    } else {
        // Only hide if player 2 hasn't selected yet
        if (!chosenCharacters.player2) {
            document.getElementById("p2-character-img").classList.add("hidden");
            document.getElementById("p2-ui").classList.add("hidden");
        }
    }
}

// ====================================
// CHARACTER OPTION INTERACTIONS (ASYNCHRONOUS)
// ====================================
document.querySelectorAll(".char-option").forEach(option => {
    const charId = option.dataset.id;
    
    // Hover preview
    option.addEventListener("mouseenter", () => {
        showCharacterPreview(charId);
    });
    
    option.addEventListener("mouseleave", () => {
        hideCharacterPreview();
    });
    
    // Click to select - CHANGED TO ASYNC
    option.addEventListener("click", async () => { 
        const char = characters[charId];
        
        // --- STEP 1: F&H CONFIRMATION (Uses custom fhConfirm) ---
        const playerName = playerTurn === 1 ? player1Name : player2Name;
        const confirmationMessage = `${playerName}, have you accepted the dreadful weight of selecting ${char.name}?`;

        const isConfirmed = await fhConfirm(confirmationMessage);

        if (!isConfirmed) {
            return; // Repudiate selected, halt.
        }

        // --- STEP 2: SELECTION CONFIRMED ---

        if (playerTurn === 1) {
            chosenCharacters.player1 = charId;
            
            // UI Updates for Player 1
            const p1Img = document.getElementById("p1-character-img");
            p1Img.src = char.img;
            p1Img.classList.remove("hidden");
            
            document.getElementById("p1-stats-text").innerHTML = char.stats;
            document.getElementById("p1-ui").classList.remove("hidden");

            // Optional: Alert for turn switch (NOW USES CUSTOM FHALERT)
            await fhAlert(`[ PLEDGE ACCEPTED ]\n\n${char.name} is bound to ${player1Name}. It is now ${player2Name}'s turn to face their choice.`);

            playerTurn = 2;

        } else {
            if(chosenCharacters.player2) return; // Prevent double clicking

            chosenCharacters.player2 = charId;
            
            // UI Updates for Player 2
            const p2Img = document.getElementById("p2-character-img");
            p2Img.src = char.img;
            p2Img.classList.remove("hidden");

            document.getElementById("p2-stats-text").innerHTML = char.stats;
            document.getElementById("p2-ui").classList.remove("hidden");

            // Save canonical keys and Transition
            localStorage.setItem("p1Character", characters[chosenCharacters.player1].key);
            localStorage.setItem("p2Character", characters[chosenCharacters.player2].key);
            
            // Optional: Final warning before transition (NOW USES CUSTOM FHALERT)
            await fhAlert(`[ THE DOORS CLOSE ]\n\nBoth characters have been chosen. Prepare for the battle in the abyss.`);

            // Transition logic 
            if (typeof PageTransition !== 'undefined' && PageTransition.navigateTo) {
                PageTransition.navigateTo("/CODE/HTML/flip.html");
            } else {
                console.warn("PageTransition.navigateTo is not defined. Attempting standard redirection.");
                window.location.href = "/CODE/HTML/flip.html";
            }
        }
    });
});