// =======================
// BGM MUSIC DEFINITION
// =======================
const BGM_SRC = '/ASSETS/SONGS/loading.mp3';
let loadingMusic = null; 

// =======================
// ELEMENTS
// =======================
const background = document.getElementById("background");
const dialogueText = document.getElementById("dialogue-text");
const pressKey = document.getElementById("press-key");

dialogueText.style.fontFamily = "Cinzel, serif";
pressKey.style.fontFamily = "Cinzel, serif";

pressKey.style.display = "none"; // hide at start

// =======================
// SOUND EFFECTS
// =======================
const lineSFX = new Audio("/ASSETS/SOUND/dialogue_blip.mp3");
lineSFX.volume = 0.6;

const rouletteSFX = new Audio("/ASSETS/SOUND/roulette_click.mp3");
rouletteSFX.volume = 0.4;

// =======================
// BACKGROUND LIST
// =======================
const bgList = [
    "/ASSETS/BG/moon_tower.png",
    "/ASSETS/BG/mausoleum_alley_dusk.png",
    "/ASSETS/BG/club.png",
    "/ASSETS/BG/forest1.png",
    "/ASSETS/BG/forest1_dusk.png",
    "/ASSETS/BG/house2_2.png",
    "/ASSETS/BG/tower.png",
    "/ASSETS/BG/slums.png"
];

// FIRST SCREEN BG
background.style.backgroundImage = `url('/ASSETS/BG/cliff1_night.png')`;

// =======================
// BACKGROUND MUSIC FUNCTIONS
// =======================

/**
 * Loads and configures the background audio track.
 */
function setupLoadingMusic() {
    loadingMusic = new Audio(BGM_SRC);
    loadingMusic.loop = true;      // Make it loop continuously
    loadingMusic.volume = 0.5;     // Set volume 
}

/**
 * Attempts to play the background music.
 */
function startLoadingMusic() {
    if (loadingMusic) {
        // Use a Promise to handle potential Autoplay blocking errors
        loadingMusic.play().catch(error => {
            console.log("Autoplay prevented:", error);
            // If autoplay fails, we attach a listener to try again on first user interaction.
            document.addEventListener('keydown', resumeMusicOnInteraction, { once: true });
            document.addEventListener('click', resumeMusicOnInteraction, { once: true });
        });
    }
}

/**
 * Resumes music playback after a necessary user interaction.
 */
function resumeMusicOnInteraction() {
    if (loadingMusic && loadingMusic.paused) {
        loadingMusic.play().catch(error => {
            console.error("Failed to resume music after interaction:", error);
        });
    }
}


// =======================
// DIALOGUE SEQUENCE
// =======================
const lines = [
    "...",
    "Hey...",
    "Wake up.",
    "It's time.."
];

function showLine(text, delay) {
    return new Promise((resolve) => {
        setTimeout(() => {
            dialogueText.style.opacity = 0;
            setTimeout(() => {
                dialogueText.textContent = text;
                dialogueText.style.opacity = 1;

                lineSFX.currentTime = 0;
                lineSFX.play();

                resolve();
            }, 1500);
        }, delay);
    });
}

async function runDialogue() {
    // 3. Start music after setting it up
    setupLoadingMusic();
    startLoadingMusic();
    
    for (let i = 0; i < lines.length; i++) {
        await showLine(lines[i], 600);
    }

    pressKey.style.display = "block"; // Show blinking "Press any key"
    waitingForContinue = true;
}

runDialogue();

// =======================
// ROULETTE SYSTEM
// =======================
let rouletteInterval = null;
let rouletteRunning = false;
let waitingForContinue = false;

function startRoulette() {
    if (rouletteRunning) return;
    rouletteRunning = true;

    rouletteInterval = setInterval(() => {
        background.style.opacity = 0;

        setTimeout(() => {
            const randomBGs = bgList.filter(bg => bg);
            const randomBG = randomBGs[Math.floor(Math.random() * randomBGs.length)];
            background.style.backgroundImage = `url('${randomBG}')`;

            background.style.opacity = 1;

            rouletteSFX.currentTime = 0;
            rouletteSFX.play();
        }, 300);

    }, 500);
}

// Stop roulette after a certain time and pick final background
function stopRouletteAndChooseFinal() {
    clearInterval(rouletteInterval);

    // --- STOP MUSIC BEFORE REDIRECT ---
    if (loadingMusic) {
        loadingMusic.pause();
        loadingMusic.currentTime = 0;
    }

    const finalBGs = bgList.filter(bg => bg);
    const finalBG = finalBGs[Math.floor(Math.random() * finalBGs.length)];
    background.style.backgroundImage = `url('${finalBG}')`;

    // Save selected background for battle
    localStorage.setItem("selectedBG", finalBG);

    // Show "Preparing battlefield..." before redirect
    dialogueText.textContent = "Preparing battlefield...";
    dialogueText.style.opacity = 1;

    // Fade out dialogue box and press key
    setTimeout(() => {
        dialogueText.style.transition = "opacity 1s ease-in-out";
        dialogueText.style.opacity = 0;
        pressKey.style.opacity = 0;
    }, 500);

    // Redirect to battle.html after fade out
    setTimeout(() => {
        PageTransition.navigateTo("/CODE/HTML/battle.html");
    }, 2000); // 2 seconds fade
}

// =======================
// KEY PRESS HANDLER
// =======================
document.addEventListener("keydown", () => {
    if (waitingForContinue && !rouletteRunning) {
        waitingForContinue = false;

        pressKey.style.display = "none";
        dialogueText.textContent = "Selecting battlefield...";

        startRoulette();

        // Stop roulette after 8 seconds
        setTimeout(stopRouletteAndChooseFinal, 8000);
    }
});