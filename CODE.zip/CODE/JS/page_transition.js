// ====================================
// GLOBAL PAGE TRANSITION UTILITY
// ====================================

const PageTransition = {
    duration: 1000,

    // Simple fade out and navigate
    navigateTo(url) {
        // Fade out body
        document.body.style.transition = 'opacity 0.8s ease-in-out';
        document.body.style.opacity = '0';
        
        // Navigate after fade completes
        setTimeout(() => {
            window.location.href = url;
        }, 800);
    },

    // Fade in on page load
    fadeInOnLoad() {
        document.body.style.opacity = '0';
        document.body.style.transition = 'opacity 1s ease-out';
        setTimeout(() => {
            document.body.style.opacity = '1';
        }, 50);
    },

    // Add fade-in class to element
    staggerElements(selector, baseDelay = 0) {
        const elements = document.querySelectorAll(selector);
        elements.forEach((el, index) => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            setTimeout(() => {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }, baseDelay + (index * 100));
        });
    }
};

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    PageTransition.fadeInOnLoad();
});
