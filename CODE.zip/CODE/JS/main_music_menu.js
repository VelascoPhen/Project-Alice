const allowedPages = [
    '/CODE/HTML/main_menu.html',
    '/CODE/HTML/start.html',
    '/CODE/HTML/credits.html'
];

if (allowedPages.includes(window.location.pathname)) {
    '/CODE/HTML/main_menu.html',
    '/CODE/HTML/start.html',
    '/CODE/HTML/credits.html'
}
const bgMusic = new Audio('/ASSETS/SONGS/main_menu.mp3');
bgMusic.loop = false;  // remove looping
bgMusic.volume = 0.7;

// Resume from last saved position
const savedTime = sessionStorage.getItem('musicTime');
if (savedTime) {
    bgMusic.currentTime = parseFloat(savedTime);
}

// Function to enable audio after first interaction
function enableMusic() {
    bgMusic.play().catch(e => console.log('Autoplay blocked:', e));
    document.removeEventListener('keydown', enableMusic);
    document.removeEventListener('click', enableMusic);
}

// Wait for user interaction
document.addEventListener('keydown', enableMusic, { once: true });
document.addEventListener('click', enableMusic, { once: true });

// Save current time
bgMusic.addEventListener('timeupdate', () => {
    sessionStorage.setItem('musicTime', bgMusic.currentTime);
});
